
public abstract class Player implements Strategy {
	
}
