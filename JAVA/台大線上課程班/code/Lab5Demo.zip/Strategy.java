
public interface Strategy {
	
	int next(int low, int high);

}
