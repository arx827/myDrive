
public class SuperAI extends NaiveAI {
	
	@Override 
	public int next(int low, int high) {
		return low;
	}

}
