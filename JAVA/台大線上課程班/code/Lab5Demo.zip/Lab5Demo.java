
public class Lab5Demo {

	public static void main(String[] args) {
		
		Game game = new Game(new SuperAI());
		game.run();

	}

}
