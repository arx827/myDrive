public class MCSimulationDemo {
    public static void main(String[] args) {

        int n = 10000;

        StdDraw.setCanvasSize(400, 400);
        StdDraw.setXscale(0, 1);
        StdDraw.setYscale(0, 1);
        
        StdDraw.line(0, 0, 1, 0);
        StdDraw.line(0, 0, 0, 1);
        for (int i = 0; i < n; i++) {
            double x = Math.random();
            double y = Math.random();
            
            if (x * x + y * y <= 1)
                StdDraw.setPenColor(StdDraw.RED);
            else
                StdDraw.setPenColor(StdDraw.BLUE);

            StdDraw.filledCircle(x, y, 0.004);
        }

    }

}
