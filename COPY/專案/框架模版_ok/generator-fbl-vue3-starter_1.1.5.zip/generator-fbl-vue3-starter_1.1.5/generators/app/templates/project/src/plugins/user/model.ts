export interface LoginState {
  accessToken: string
  me: {}
}
