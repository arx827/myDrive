<script setup lang="ts"></script>
<template>
  <div id="notfound__page">
    <h1 class="notfound__text text-center">404 not found</h1>
  </div>
</template>
<style lang="scss" scoped>
#notfound__page {
  background-color: $COLOR-MAIN1;
  height: 100vh;
  display: grid;
  align-items: center;
  > * {
    color: white;
  }
}
</style>
