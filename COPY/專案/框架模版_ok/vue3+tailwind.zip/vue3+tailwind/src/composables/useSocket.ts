import { ref, getCurrentInstance, nextTick, watch } from 'vue'
import SockJS from 'sockjs-client/dist/sockjs.min.js'
import Stomp from 'stompjs'
import { useUser } from '@stores/useUser'
import { storeToRefs } from 'pinia'
import { useOnDutyStore } from '@stores/useOnDutyStore'
import { useLoadingStore } from '@/stores'

import { useChatMonitoringStores } from '@stores/useChatMonitoringStores'
import dayjs from 'dayjs'

const {
  setMessage_previewClient,
  cleanMessage_previewClient,
  addChatMonitoringList,
  removeChatMonitoring,
  setNoResponseDuration,
  setChatMonitoringWsMessage,
  setRobotMessage,
} = useChatMonitoringStores()

const { getChatMonitoringChatRoomNameList } = storeToRefs(useChatMonitoringStores())

import { message } from 'ant-design-vue'

import { useRoute } from 'vue-router'

const { getServiceInfo } = storeToRefs(useUser())
const { setLoading } = useLoadingStore()

const {
  setHeaderData,
  addConversation,
  setOnDutyWsMessage,
  removeConversation,
  clientLeaveRoom,
  setOnDutyClientLeaveWsMessage,
  createCountdownTimer,
} = useOnDutyStore()
const { getRoleId, getActiveChatroomName, getConversationArr } = storeToRefs(useOnDutyStore())
// 參考 https://juejin.cn/post/7236325900718440507
// 參考 https://juejin.cn/post/7107266882415099934
let sock
let stomp: any
let errorNum: number = 0

const chatroomStatus: { label: string; value: number }[] = [
  { label: '系統提示 : 客戶主動放棄等待', value: 3 },
  { label: '系統提示 : 客戶主動結束聊天', value: 4 },
  { label: '系統提示 : 長時間未活動，系統結束服務', value: 5 },
  { label: '系統提示 : 客戶主動結束聊天', value: 6 },
  { label: '系統提示 : 客服已結束聊天', value: 7 },
]

export const useSocket = () => {
  // create socket 連線
  const openSocket = (saveLog = undefined) => {
    sock = new SockJS(import.meta.env.VITE_WS_URL)
    stomp = Stomp.over(sock)
    return new Promise((resolve, reject) => {
      stomp.connect(
        {},
        () => {
          errorNum = 0 // 歸零
          resolve('連線成功')
          // LOG => socket_建立連線成功
          saveLog?.('socket_建立連線成功')
        },
        () => {
          errorNum += 1
          if (errorNum < 30) {
            openSocket(saveLog)
          } else {
            // 超過最大連線數，就不再重新連線
            reject('超過socket錯誤連線次數，請重新操作流程')
            console.error('超過socket錯誤連線次數，請重新操作流程')

            // LOG => socket_建立連線失敗
            saveLog?.('socket_建立連線失敗')
          }
        },
      )
    })
  }

  // 取消整個 socket 連線
  const disconnect = () => {
    stomp.disconnect()
  }

  // 訂閱
  const subscribe = async (title: string, url: string, callback) => {
    // 排除已訂閱
    if (!Object.keys(stomp.subscriptions).includes(title)) {
      // console.log('TEST: 訂閱 =>', title)
      await stomp.subscribe(url, callback, { id: title })
    }
  }

  // 發送
  const send = (url: string, body) => {
    if (typeof body === 'object') {
      body = JSON.stringify(body)
    }
    stomp.send(url, {}, body)
  }

  // 取消訂閱
  const unsubscribe = (title: string, type?: string) => {
    // 全部清除
    if (type === 'all') {
      Object.keys(stomp.subscriptions).map(i => {
        if (i.includes(title)) {
          stomp.unsubscribe(i)
          // console.log('TEST: 取消訂閱 =>', i)
        }
      })
    } else {
      if (Object.keys(stomp.subscriptions).includes(title)) {
        stomp.unsubscribe(title)
        // console.log('TEST: 取消訂閱 =>', title)
      }
    }
  }

  // 關閉 聊天房間 對話連線 (客戶離開，客服主動離開)
  const closeChatRoomLive = (chatroomName, saveLog) => {
    // 取消 socket 目前即時聊天
    unsubscribe(`receiveMessage_${chatroomName}`)

    // 取消 socket 預覽客戶發送訊息
    unsubscribe(`previewClientMessage_${chatroomName}`)

    // 取消 socket 離開事件
    unsubscribe(`quitChatroomEvent_${chatroomName}`)

    // 清空 預覽客戶發送訊息
    cleanMessage_previewClient(chatroomName)

    // 關閉 倒數器
    const $findRoom = getConversationArr.value.find(i => i.chatroomName === chatroomName)
    clearInterval($findRoom.countdownTimer)
  }

  const getChatroomStatusLabel = status => {
    const target = chatroomStatus.find(i => i.value === status)
    return target ? target.label : null
  }

  // 派件處理
  const dispatchAttendantFunc = (attendantId, $result, saveLog) => {
    if (addConversation($result)) {
      // 初始 閒置倒數
      // 啟動 倒數器
      const $findRoom = getConversationArr.value.find(i => i.chatroomName === $result.chatroomName)
      $findRoom.countdownTimer = createCountdownTimer(
        $findRoom,
        () => {
          // 傳送到前台 客戶閒置 告警
          socketUtil.socketSend_sendMessage({
            chatroomId: $result.chatroomId,
            chatroomName: $result.chatroomName,
            messageSendClient: 2,
            messageType: 1,
            messageContent: '溫馨提醒：已逾2分鐘尚未收到您的回應，系統將於1分鐘後主動結束此通文字交談。',
            attendantId: getServiceInfo.value.userId,
            attendantName: getRoleId.value.attendantName,
            sendTime: dayjs(),
          })
        },
        () => {
          // (客戶閒置 踢退)時
          // (主動) 傳送離開狀態
          socketUtil.socketSend_quitChatroomEvent(
            {
              chatroomId: $result.chatroomId,
              chatroomName: $result.chatroomName,
              chatroomStatus: 5, // 設置客戶閒置
            },
            saveLog,
          )

          // (主動) 後台 出現客戶離開訊息
          setOnDutyClientLeaveWsMessage($result.chatroomName, {
            chatroomId: $result.chatroomId,
            chatroomName: $result.chatroomName,
            messageSendClient: 1,
            messageType: 1,
            messageContent: '系統提示 : 長時間未活動，系統結束服務',
            attendantId: getServiceInfo.value.userId,
            attendantName: getRoleId.value.attendantName,
            sendTime: dayjs(),
          })

          // LOG => 離開事件 => quit_{attendantId}_{chatName}_{quitEvent}
          saveLog?.(`離開事件 => quit_${getServiceInfo.value.userId}_${$result.chatroomName}_5`)

          // client Leave room
          clientLeaveRoom($result.chatroomName)

          // closeChatRoomLive 聊天室
          closeChatRoomLive($result.chatroomName, saveLog)

          // 通知 CSWR 結束進線
          const icsChatroom = window.chrome.webview.hostObjects.sync.icsChatroom
          icsChatroom.EndChat()
        },
      )

      // 訂閱 即時聊天室內容 (含 接收訊息後 重置 閒置倒數)
      socketUtil.socket_receiveMessage_dispatchAttendant($result.chatroomName, saveLog)
      // 訂閱 離開事件
      socketUtil.socket_quitChatroomEvent($result, saveLog)

      // 通知 CSWR 進線
      const icsChatroom = window.chrome.webview.hostObjects.sync.icsChatroom
      icsChatroom.StartChat($result.cswrRecordId, $result.clientId, $result.chatroomId, attendantId) //   (接收socket 即時派件機制 時呼叫)
    }
  }

  // socket 訂閱清單
  const socketUtil = {
    // --------------------------------------- 值機端 --------------------------------------- //
    // 6.2.14 平台即時服務狀態
    socket_clientMonitoringResult: (saveLog = undefined) => {
      subscribe('clientMonitoringResult', '/topic/clientMonitoringResult', result => {
        const $result = JSON.parse(result.body)
        setHeaderData('clientOnChatCounts', $result.clientOnChatCounts)
        setHeaderData('clientOnWaitCounts', $result.clientOnWaitCounts)
        setHeaderData('chattingTimeDuration', $result.chattingTimeDuration)
        setHeaderData('waitingTimeDuration', $result.waitingTimeDuration)
        setHeaderData('clientOnQuitCounts', $result.clientOnQuitCounts)
        setHeaderData('clientOnQuitPercentage', $result.clientOnQuitPercentage)
        setHeaderData('activeCount', $result.activeCount)
        setHeaderData('standByCount', $result.standByCount)
        setHeaderData('busyCount', $result.busyCount)
      })

      // LOG => 訂閱 => clientMonitoringResult
      saveLog?.('訂閱 => clientMonitoringResult')
    },

    // 6.2.15 客戶即時派件服務頁籤 (on-Duty 即時派件機制)
    socket_dispatchAttendant: (attendantId: string, saveLog = undefined) => {
      // 即時派件 只會有一筆訂閱，其他都刪掉
      Object.keys(stomp.subscriptions).map(i => {
        if (i.includes('dispatchAttendant') && i.split('_')[1] !== attendantId) {
          unsubscribe(i)
        }
      })
      subscribe(`dispatchAttendant_${attendantId}`, `/queue/dispatchAttendant/${attendantId}`, result => {
        const $result = JSON.parse(result.body)
        dispatchAttendantFunc(attendantId, $result, saveLog)
      })

      // LOG => 訂閱 => dispatchAttendant_{attendantId}
      saveLog?.(`訂閱 => dispatchAttendant_${attendantId}`)
    },

    // 即時聊天室內容 (訂閱) (on-duty)
    socket_receiveMessage_dispatchAttendant: (chatroomName: string, saveLog) => {
      subscribe(`receiveMessage_${chatroomName}`, `/queue/receiveMessage/${chatroomName}`, result => {
        const $result = JSON.parse(result.body)

        // 新增 ws 訊息，並宣告 客戶閒置處理方式 (離開事件：5)
        setOnDutyWsMessage(
          chatroomName,
          $result,
          () => {
            // 傳送到前台 客戶閒置 告警
            socketUtil.socketSend_sendMessage({
              chatroomId: $result.chatroomId,
              chatroomName: $result.chatroomName,
              messageSendClient: 2,
              messageType: 1,
              messageContent: '溫馨提醒：已逾2分鐘尚未收到您的回應，系統將於1分鐘後主動結束此通文字交談。',
              attendantId: getServiceInfo.value.userId,
              attendantName: getRoleId.value.attendantName,
              sendTime: dayjs(),
            })
          },
          () => {
            // (客戶閒置 踢退)時
            // (主動) 傳送離開狀態
            socketUtil.socketSend_quitChatroomEvent(
              {
                chatroomId: $result.chatroomId,
                chatroomName,
                chatroomStatus: 5, // 設置客戶閒置
              },
              saveLog,
            )

            // (主動) 後台 出現客戶離開訊息
            setOnDutyClientLeaveWsMessage($result.chatroomName, {
              chatroomId: $result.chatroomId,
              chatroomName: $result.chatroomName,
              messageSendClient: 1,
              messageType: 1,
              messageContent: '系統提示 : 長時間未活動，系統結束服務',
              attendantId: getServiceInfo.value.userId,
              attendantName: getRoleId.value.attendantName,
              sendTime: dayjs(),
            })

            // LOG => 離開事件 => quit_{attendantId}_{chatName}_{quitEvent}
            saveLog?.(`離開事件 => quit_${getServiceInfo.value.userId}_${$result.chatroomName}_5`)

            // client Leave room
            clientLeaveRoom($result.chatroomName)

            // closeChatRoomLive 聊天室
            closeChatRoomLive($result.chatroomName, saveLog)

            // 通知 CSWR 結束進線
            const icsChatroom = window.chrome.webview.hostObjects.sync.icsChatroom
            icsChatroom.EndChat()
          },
        )
      })

      // LOG => 訂閱 => chatroomMessage_{chatName}
      saveLog?.(`訂閱 => chatroomMessage_${chatroomName}`)
    },

    // 聊天內容發送 (發送)
    socketSend_sendMessage: obj => {
      send('/app/sendMessage', {
        instantMessageType: 1,
        message: JSON.stringify(obj),
      })
    },

    // 預覽客戶發送訊息 (訂閱)
    socket_previewClientMessage: (chatroomName: string, saveLog = undefined) => {
      subscribe(`previewClientMessage_${chatroomName}`, `/queue/previewClientMessage/${chatroomName}`, result => {
        const $result = JSON.parse(result.body)
        setMessage_previewClient(chatroomName, $result.messageContent)
      })

      // LOG => 訂閱 => chatroomPreviewMessage_{chatName}
      saveLog?.(`訂閱 => chatroomPreviewMessage_${chatroomName}`)
    },

    // 離開事件 (on-Duty 訂閱)
    socket_quitChatroomEvent: (chatroom, saveLog = undefined) => {
      subscribe(
        `quitChatroomEvent_${chatroom.chatroomName}`,
        `/queue/quitChatroomEvent/${chatroom.chatroomName}`,
        result => {
          const $result = JSON.parse(result.body)

          // 查找 chatroomName 相對資料
          const $findInfo = getConversationArr.value.find(i => i.chatroomName === $result.chatroomName)

          // 客戶 離開事件(4、6)，後台自己加訊息
          setOnDutyClientLeaveWsMessage($result.chatroomName, {
            chatroomId: $findInfo.chatroomId,
            chatroomName: $result.chatroomName,
            messageSendClient: 1,
            messageType: 1,
            messageContent: getChatroomStatusLabel($result.chatroomStatus),
            attendantId: getServiceInfo.value.userId,
            attendantName: getRoleId.value.attendantName,
            sendTime: dayjs(),
          })

          // LOG => 離開事件 => quit_{attendantId}_{chatName}_{quitEvent}
          saveLog?.(`離開事件 => quit_${getServiceInfo.value.userId}_${$result.chatroomName}_${$result.chatroomStatus}`)

          // client Leave room
          clientLeaveRoom($findInfo.chatroomName)

          // closeChatRoomLive 聊天室
          closeChatRoomLive($findInfo.chatroomName, saveLog)

          // 通知 CSWR 結束進線
          const icsChatroom = window.chrome.webview.hostObjects.sync.icsChatroom
          icsChatroom.EndChat()
        },
      )

      // LOG => 訂閱 => chatroomQuit_{chatName}
      saveLog?.(`訂閱 => chatroomQuit_${chatroom.chatroomName}`)
    },

    // 離開事件 (發送訊息)(5、7)
    socketSend_quitChatroomEvent: (payload, saveLog = undefined) => {
      send('/app/quitChatroomEvent', {
        instantMessageType: 9,
        message: JSON.stringify(payload),
      })
      closeChatRoomLive(payload.chatroomName, saveLog)

      if (payload.chatroomStatus === 7) {
        // 離開 並 主動關閉 聊天房
        removeConversation()
      }

      // LOG => 離開事件 => quit_{attendantId}_{chatName}_{quitEvent}
      saveLog?.(`離開事件 => quit_${getServiceInfo.value.userId}_${payload.chatroomName}_${payload.chatroomStatus}`)
    },

    // 未回覆時長 (發送訊息)
    socketSend_noResponseDuration: (duration: string, chatroomName: string) => {
      send('/app/noResponseDuration', {
        instantMessageType: 7,
        message: JSON.stringify({
          chatroomName,
          duration,
        }),
      })
    },

    // --------------------------------------- 即時交談監控 --------------------------------------- //
    // 目前正在交談中的線上客戶
    socket_onlineChattingClients: () => {
      subscribe('onlineChattingClients', '/topic/onlineChattingClients', result => {
        const $result = JSON.parse(result.body)
        const $resultChatroomNameArr = $result.map(i => i.chatroomName) // 此筆訂閱的 所有 chatroomName
        const $subscriptionsKeys = Object.keys(stomp.subscriptions) // 已訂閱socket 列表
        // 處理新增訂閱 ($result，不包含在 已訂閱的列表中)
        $result.map(i => {
          // 處理新增 上方列表
          if (addChatMonitoringList(i)) {
            // 訂閱 未回覆時長
            socketUtil.socket_noResponseDuration(i.chatroomName)

            // 訂閱 即時聊天室內容
            socketUtil.socket_receiveMessage_onlineChatting(i.chatroomName)
          }
        })

        // 處理刪除 上方列表
        getChatMonitoringChatRoomNameList.value.map(i => {
          if (!$resultChatroomNameArr.includes(i)) {
            removeChatMonitoring(i)
          }
        })

        // 處理取消訂閱 (已訂閱的列表，不包含在 $result 中)
        $subscriptionsKeys.map(i => {
          const $chatroomName = i.split('_')[1]
          if (!$resultChatroomNameArr.includes($chatroomName)) {
            if (i.includes('noResponseDuration')) {
              // 取消 未回覆時長
              unsubscribe(`noResponseDuration_${$chatroomName}`)
            }

            if (i.includes('receiveMessage')) {
              // 取消 即時聊天
              unsubscribe(`receiveMessage_${$chatroomName}`)
            }
          }
          if (i.includes('receiveMessage') && !$resultChatroomNameArr.includes($chatroomName)) {
            // 取消 即時聊天
            unsubscribe(`receiveMessage_${$chatroomName}`)
          }
        })
      })
    },

    // 未回覆時長 (訂閱)
    socket_noResponseDuration: (chatroomName: string) => {
      subscribe(`noResponseDuration_${chatroomName}`, `/queue/noResponseDuration/${chatroomName}`, result => {
        const $result = JSON.parse(result.body)
        if ($result.duration.trim()) {
          setNoResponseDuration($result.chatroomName, $result.duration)
        }
      })
    },

    // 即時聊天室內容 (即時交談監控)
    socket_receiveMessage_onlineChatting: (chatroomName: string) => {
      subscribe(`receiveMessage_${chatroomName}`, `/queue/receiveMessage/${chatroomName}`, result => {
        const $result = JSON.parse(result.body)
        setChatMonitoringWsMessage(chatroomName, $result)
      })
    },
  }

  return {
    openSocket,
    disconnect,
    subscribe,
    unsubscribe,
    dispatchAttendantFunc,
    socketUtil,
  }
}
