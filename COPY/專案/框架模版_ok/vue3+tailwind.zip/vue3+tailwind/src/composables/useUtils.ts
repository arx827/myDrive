import { ref } from 'vue'
import rangMp3 from '@audio/rang.mp3'
export const useUtils = () => {
  // 後台 功能性頁面 bgicon 是
  const bgClass = (bgName: unknown): string => {
    return bgName ? `${bgName} pb-[130px]` : 'pb-[10px]'
  }

  // 換算時間 (上午、下午)
  const getTime = date => {
    const myDate = new Date(date)
    const hours = myDate.getHours() % 12 || 12
    const pmam = myDate.getHours() < 12 ? '上午' : '下午'
    const minutes = myDate.getMinutes() < 10 ? '0' + myDate.getMinutes() : myDate.getMinutes()
    const time = pmam + ' ' + hours + ':' + minutes
    return time
  }

  return {
    bgClass,
    getTime,
  }
}
