<script setup lang="ts">
import { ref } from 'vue'
import zhTW from 'ant-design-vue/es/locale/zh_TW'
import dayjs from 'dayjs'
import 'dayjs/locale/zh-tw'

dayjs.locale('zh-tw')
const locale = ref(zhTW)
// 解決 下拉選單 跟隨頁面滾動
const getPopupContainer = triggerNode => {
  return triggerNode ? triggerNode.parentNode : document.body
}

const appRef = ref(null)
</script>

<template>
  <a-config-provider :locale="locale" :getPopupContainer="getPopupContainer">
    <div ref="appRef" class="main__content flex flex-col">
      <RouterView />
    </div>
  </a-config-provider>
</template>

<style lang="postcss">
#app {
  min-height: 100vh;
}
</style>
