import { createRouter, createWebHashHistory } from 'vue-router'
import type { RouteRecordRaw } from 'vue-router'
import message from '@plugins/message'
import user from '@plugins/user'

import 'vue-router'

import importCompVue from './importVue'

declare module 'vue-router' {
  interface RouteMeta {
    breadcrumb?: {
      mainTitle: string
      subTitle?: string[]
    }
  }
}

const routes: Array<RouteRecordRaw> = [
  /* === 後台 === */
  {
    path: '/',
    name: 'home',
    component: importCompVue.MainPageVue,

    // beforeEnter(to, from, next) {
    //   if (!user.hasValidToken()) {
    //     message.warning({ content: '尚未登入' })
    //     next({ name: 'Login' })
    //   } else {
    //     next()
    //   }
    // },
  },
  // 無法識別的path => 匹配 notFound
  { path: '/not-found', name: 'NotFound', component: importCompVue.NotFoundVue },
  { path: '/:catchAll(.*)*', component: importCompVue.NotFoundVue },
]

const router = createRouter({
  history: createWebHashHistory(import.meta.env.BASE_URL),
  routes,
  scrollBehavior(to, from, savedPosition) {
    const $main = document.querySelector('.main__content')
    if ($main) {
      $main.scrollTop = 0
    }
  },
})

// 網址未匹配處理
router.beforeEach(async (to, from, next) => {
  if (import.meta.env.BASE_URL !== window.location.pathname) {
    window.location.href = `${new URL(import.meta.url).origin}${import.meta.env.BASE_URL}#/not-found`
  } else {
    await next()
  }
})

export default router
