import NotFoundVue from '@/pages/NotFound.vue'
import MainPageVue from '@pages/MainPage.vue'

export default {
  NotFoundVue,
  MainPageVue,
}
