<script setup lang="ts"></script>
<template>
  <Loading />
  <div class="m-[16px] flex min-h-[calc(100vh-32px)] rounded-[4px] bg-transparent bg-white">
    <RouterView />
  </div>
</template>

<style scoped></style>
