export enum FblColumnType {
  PLAIN = 'PLAIN',
  TEMPLATE = 'TEMPLATE',
}
